package com.shilladfs.spot.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class Sample {
	
	@NotBlank
	private Long sampleId;
	
	@NotBlank
	private String name;
	
	

}
